<?php

namespace app\system\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\console\input\Option;
use think\Db;
use think\facade\Env;


class AiImageCommand extends Command
{
    /**
     * 命令配置
     */
    protected function configure()
    {
        $this->setName('ai:image')
            ->setDescription('使用阿里千问Image-Edit-Plus模型生成新图片')
            ->addOption('tl-level', null, Option::VALUE_OPTIONAL, '题目等级', 1)
            ->addOption('start', null, Option::VALUE_OPTIONAL, '题目ID开始范围', 1)
            ->addOption('end', null, Option::VALUE_OPTIONAL, '题目ID结束范围', 1000)
            //->addOption('soft', null, Option::VALUE_OPTIONAL, '排序值', '6,7')
            ->addOption('batch-size', null, Option::VALUE_OPTIONAL, '批处理大小', 10)
            ->addOption('stop', null, Option::VALUE_NONE, '停止任务');
    }
    
    /**
     * 执行命令
     * @param Input $input
     * @param Output $output
     * @return void
     */
    protected function execute(Input $input, Output $output)
    {
        // 获取命令参数
        $tl_level       = $input->getOption('tl-level');
        $start_tl_id    = $input->getOption('start');
        $end_tl_id      = $input->getOption('end');
        $batch_size     = $input->getOption('batch-size');
        $stop           = $input->getOption('stop');
        
        // 检查停止命令
        if ($stop) {
            $this->stopTask($output);
            return;
        }
        
        // 输出开始信息
        $output->writeln('=======================================');
        $output->writeln('    阿里千问图片生成工具 v1.0');
        $output->writeln('=======================================');
        $output->writeln('参数配置:');
        $output->writeln('  题目等级: ' . $tl_level);
        $output->writeln('  题目ID范围: ' . $start_tl_id . ' - ' . $end_tl_id);
        $output->writeln('  批处理大小: ' . $batch_size);
        $output->writeln('---------------------------------------');
        
        // 准备任务
        $progress_file = Env::get('runtime_path') . 'ai_image_progress.json';
        $stop_file     = Env::get('runtime_path') . 'ai_image_stop.flag';
        
        // 检查是否有暂停的任务
        if (file_exists($progress_file)) {
            $progress = json_decode(file_get_contents($progress_file), true);
            if ($progress && $progress['status'] == 'paused') {
                $output->writeln('检测到暂停的任务，是否继续? (y/n)');
                $continue = trim(fgets(STDIN));
                if (strtolower($continue) == 'y') {
                    $output->writeln('继续之前的任务...');
                } else {
                    $output->writeln('取消任务');
                    @unlink($progress_file);
                    return;
                }
            }
        }
        
        // 查询数据
        $output->writeln('查询题目数据...');
        $questions = Db::name('topic_questions')
            ->where('tl_level', $tl_level)
            ->where('tl_id', 'between', [$start_tl_id, $end_tl_id])
            //->where('soft', 'in', [6,7])
            ->order('tl_id asc, soft asc')
            ->select();
        if (empty($questions)) {
            $output->writeln('❌ 未找到符合条件的题目数据');
            return;
        }
        
        $total = count($questions);
        $output->writeln('✅ 找到 ' . $total . ' 条题目数据');
        $output->writeln('开始生成图片...');
        $output->writeln('---------------------------------------');
        
        // 初始化统计信息
        $start_time = time();
        $success_count = 0;
        $fail_count = 0;
        $skip_count = 0;
        
        // 处理每条数据
        foreach ($questions as $index => $question) {
            // 检查停止信号
            if (file_exists($stop_file)) {
                $this->saveProgress($progress_file, $index, $total, $success_count, $fail_count, $skip_count, $start_time, 'paused');
                $output->writeln('\n🛑 检测到停止信号，任务已暂停');
                @unlink($stop_file);
                return;
            }
            
            // 显示进度
            $current = $index + 1;
            $output->writeln('正在处理第 ' . $current . '/' . $total . ' 条数据 (tl_id: ' . $question['tl_id'] . ', soft: ' . $question['soft'] . ')');
            
            try {
                // 解析题目数据
                $find_question = json_decode($question['questions'], true);
                if (empty($find_question)) {
                    $output->writeln('  ⚠ 跳过: 题目数据为空');
                    $skip_count++;
                    continue;
                }
                
                // 处理每张图片
                $processed_images = 0;
                //$total_images = count($find_question);
                
                foreach ($find_question as $key_2 => &$value_2) {
                    // 处理图片路径
                    $image = str_replace('http://www.xyz.com/', '/', $value_2['image']);
                    $path_image = '.' . $image;
                    
                    // 检查图片文件是否存在
                    if (!file_exists($path_image)) {
                        $output->writeln('  ⚠ 跳过: 图片文件不存在 (' . $image . ')');
                        continue;
                    }
                    
                    // 检查是否已生成过AI图片
                    $path_data = explode('/img-', $path_image);
                    if (count($path_data) < 2) {
                        $output->writeln('  ⚠ 跳过: 图片路径格式不正确');
                        continue;
                    }
                    
                    $path = $path_data[0];
                    $image_name = 'ai-img-' . $path_data[1];
                    
                    if (file_exists($path . '/' . $image_name)) {
                        $output->writeln('  ✅ 跳过: AI图片已存在');
                        $skip_count++;
                        continue;
                    }
                    
                    // 转换图片为base64
                    $base64_data = $this->ImageUrlToBase64($path_image);
                    if (!$base64_data) {
                        $output->writeln('  ❌ 失败: 图片转换base64失败');
                        continue;
                    }
                    
                    // 生成提示词
                    $english = $value_2['english'];
                    $prompt = '当前图片主题含义为："' . $english . '",请按照英文含义保持图片展示的内容贴合含义,对背景、人物风格、着装色彩、整体图片布局进行改变(让其看起来和参考图的相似度不高于40%，并生成的图片还能准确的表达出英文所表达的含义),图片风格修改为亚洲现代写实风格;';
                    
                    // 调用AI生图API
                    $output->writeln('  📤 调用AI生图API...');
                    $result = $this->QianWenAiImage($prompt, $base64_data, $path, $image_name);
                    
                    if ($result) {
                        // 更新图片路径
                        // $new_image_url = str_replace('http://www.xyz.com/', '/', $image_name);
                        // $value_2['image'] = 'http://www.xyz.com/' . ltrim($new_image_url, '/');
                        $processed_images++;
                        $output->writeln('  ✅ 成功: AI图片生成完成');
                    } else {
                        $output->writeln('  ❌ 失败: AI图片生成失败');
                        $fail_count++;
                    }
                }
                
                // 如果有图片被处理，更新数据库
                 if ($processed_images > 0) {
                //     Db::name('topic_questions')->where('id', $question['id'])->update([
                //         'questions' => json_encode($find_question, JSON_UNESCAPED_UNICODE),
                //         'update_time' => time()
                //     ]);
                     $success_count++;
                 }
                
                // 保存进度
                $this->saveProgress($progress_file, $current, $total, $success_count, $fail_count, $skip_count, $start_time, 'running');
                
                // 批处理延迟
                if (($index + 1) % $batch_size == 0) {
                    $delay = rand(1, 3);
                    $output->writeln('  ⏳ 批处理完成，休息 ' . $delay . ' 秒...');
                    sleep($delay);
                }
                
            } catch (\Exception $e) {
                $output->writeln('  ❌ 错误: ' . $e->getMessage());
                $fail_count++;
                
                // 保存进度
                $this->saveProgress($progress_file, $current, $total, $success_count, $fail_count, $skip_count, $start_time, 'running');
            }
            
            $output->writeln('');
        }
        
        // 清理进度文件
        if (file_exists($progress_file)) {
            @unlink($progress_file);
        }
        
        // 输出统计信息
        $output->writeln('---------------------------------------');
        $output->writeln('任务完成!');
        $output->writeln('总耗时: ' . (time() - $start_time) . ' 秒');
        $output->writeln('处理题目: ' . $total . ' 条');
        $output->writeln('成功生成: ' . $success_count . ' 条');
        $output->writeln('生成失败: ' . $fail_count . ' 条');
        $output->writeln('跳过处理: ' . $skip_count . ' 条');
        $output->writeln('=======================================');
    }
    
    /**
     * 停止任务
     * @param Output $output
     */
    private function stopTask(Output $output)
    {
        $stop_file = Env::get('runtime_path') . 'ai_image_stop.flag';
        
        if (file_exists($stop_file)) {
            $output->writeln('❌ 已经存在停止信号');
            return;
        }
        
        file_put_contents($stop_file, time());
        $output->writeln('✅ 已发送停止信号，任务将在当前批次完成后停止');
    }
    
    /**
     * 保存任务进度
     * @param string $progress_file
     * @param int $current
     * @param int $total
     * @param int $success
     * @param int $fail
     * @param int $skip
     * @param int $start_time
     * @param string $status
     */
    private function saveProgress($progress_file, $current, $total, $success, $fail, $skip, $start_time, $status)
    {
        file_put_contents($progress_file, json_encode([
            'current' => $current,
            'total' => $total,
            'success' => $success,
            'fail' => $fail,
            'skip' => $skip,
            'start_time' => $start_time,
            'status' => $status
        ]));
    }
    
    /**
     * 将图片转换为base64编码
     * @param string $path 图片路径或URL
     * @return string|false 返回base64编码的图片数据或false
     */
    private function ImageUrlToBase64($path)
    {
        try {
            // 检查是否为远程URL
            if (filter_var($path, FILTER_VALIDATE_URL)) {
                // 对于远程URL，直接使用file_get_contents获取
                $image_data = file_get_contents($path);
                if ($image_data === false) {
                    throw new Exception('远程图片获取失败');
                }
            } else {
                // 对于本地路径，先检查文件是否存在
                if (!file_exists($path)) {
                    throw new Exception('本地图片文件不存在');
                }
                $image_data = file_get_contents($path);
                if ($image_data === false) {
                    throw new Exception('本地图片读取失败');
                }
            }
            
            // 获取图片MIME类型
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime_type = finfo_buffer($finfo, $image_data);
            finfo_close($finfo);
            
            // 验证是否为有效的图片类型
            if (strpos($mime_type, 'image/') !== 0) {
                throw new Exception('文件不是有效的图片类型');
            }
            
            // 转换为base64编码
            $base64_data = base64_encode($image_data);
            
            // 返回完整的base64字符串（包含data URI scheme）
            return 'data:' . $mime_type . ';base64,' . $base64_data;
            
        } catch (Exception $e) {
            // 错误处理：可以根据需要记录日志或返回错误信息
            // 这里简单返回false表示失败
            return false;
        }
    }
    
    /**
     * 调用阿里千问Image-Edit-Plus API
     * @param string $prompt 提示词
     * @param string $base_image base64编码的图片
     * @param string $path 保存路径
     * @param string $image_name 保存文件名
     * @return bool 是否成功
     */
    private function QianWenAiImage($prompt, $base_image, $path, $image_name)
    {
        // 参数验证
        if (empty($prompt) || empty($base_image)) {
            return false;
        }
        
        try {
            // 调用阿里千问Image-Edit-Plus API
            $access_key_id = 'sk-1093c59b20da43bdb84c436c8d7e7dda'; // 请替换为实际的阿里云AccessKey ID
            $api_url = 'https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation';
            $model = 'qwen-image-edit-plus';
            
            // 准备请求参数
            $request_data = [
                'model' => $model,
                'input' => [
                    'messages' => [
                        [
                            'role' => 'user',
                            'content' => [
                                ['image' => $base_image],
                                ['text' => $prompt],
                            ]
                        ]
                    ],
                ],
                'parameters' => [
                    'n' => 1,
                    'negative_prompt' => '',
                    'prompt_extend' => true,
                    'watermark' => false, // 水印
                ]
            ];
            
            $payload = json_encode($request_data);
            
            // 生成签名
            $timestamp   = time();
            $nonce       = uniqid();
            $payload     = json_encode($request_data);
            $headers = [
                'Content-Type: application/json; charset=utf-8',
                'Authorization: Bearer ' . $access_key_id
            ];
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $api_url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            if (curl_errno($ch)) {
                throw new Exception('API请求失败: ' . curl_error($ch));
            }
            curl_close($ch);
            
            // 处理响应
            $result = json_decode($response, true);
            
            if ($http_code !== 200 || !isset($result['output']['choices'][0]['message']['content'][0]['image'])) {
                throw new Exception('API调用失败: ' . ($result['message'] ?? '未知错误'));
            }
            
            // 下载生成的图片
            $generated_image_url = $result['output']['choices'][0]['message']['content'][0]['image'];
            $generated_image_content = file_get_contents($generated_image_url);
            
            if (!$generated_image_content) {
                throw new Exception('下载生成的图片失败');
            }
            
            // 保存图片
            $full_path = $path . '/' . $image_name;
            if (!file_put_contents($full_path, $generated_image_content)) {
                throw new Exception('保存图片失败');
            }
            return true;
        } catch (Exception $e) {
            // 记录错误信息
            file_put_contents(Env::get('runtime_path') . 'ai_image_error.log', date('Y-m-d H:i:s') . ' - ' . $e->getMessage() . "\n", FILE_APPEND);
            return false;
        }
    }
}