<?php

namespace app\system\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\console\input\Argument;
use think\console\input\Option;
use think\Db;
use think\facade\Env;

class SyncQuestions extends Command
{
    protected function configure()
    {
        $this->setName('sync:questions')
            ->setDescription('同步题目数据或解锁关卡')
            ->addOption('unlock', null, Option::VALUE_NONE, '是否执行关卡解锁模式')
            ->addOption('chapter', null, Option::VALUE_OPTIONAL, '章节ID', 1)
            ->addOption('course', null, Option::VALUE_OPTIONAL, '课程ID', 1)
            ->addOption('start', null, Option::VALUE_OPTIONAL, '起始关卡/题目号', 1)
            ->addOption('end', null, Option::VALUE_OPTIONAL, '结束关卡/题目号', 1000);
    }

    protected function execute(Input $input, Output $output)
    {
        //php think sync:questions --start 1 --end 32 --chapter 2 --course 1
        $isUnlock = $input->getOption('unlock');
        if ($isUnlock) {
            $this->unlock_levels($input, $output);
            return;
        }
        $start = $input->getOption('start') ?: 1;
        $total = $input->getOption('end') ?: 1000;
        $chapter_id = $input->getOption('chapter') ?: 1;
        $course_id = $input->getOption('course') ?: 1;
        $output->writeln("开始同步题目数据: start={$start}, total={$total}");
        
        $startTime = time();
        $successCount = 0;
        $noDataCount = 0;
        $failCount = 0;
        
        $url = "https://www.baidu.com";
        $post_data = [
            'chapter_id'    => $chapter_id,
            'course_id'     => $course_id,
        ];
        
        $progress_file = Env::get('runtime_path') . 'sync_questions_progress.json';
        $stop_file = Env::get('runtime_path') . 'sync_questions_stop.flag';
        
        for ($i = $start; $i <= $total; $i++) {
            // 检查停止标志
            if (file_exists($stop_file)) {
                $output->writeln("检测到停止信号，任务暂停于第 {$i} 条");
                file_put_contents($progress_file, json_encode([
                    'current' => $i - 1,
                    'total' => $total,
                    'success' => $successCount,
                    'no_data' => $noDataCount,
                    'fail' => $failCount,
                    'start_time' => $startTime,
                    'status' => 'paused'
                ]));
                @unlink($stop_file);
                return;
            }
            
            $post_data['level_number'] = $i;
            
            file_put_contents($progress_file, json_encode([
                'current' => $i,
                'total' => $total,
                'success' => $successCount,
                'no_data' => $noDataCount,
                'fail' => $failCount,
                'start_time' => $startTime,
                'status' => 'running'
            ]));
            $token = $this->post_login('https://www.login.com','','');
            $maxRetries = 3;
            $retryCount = 0;
            $res = null;
            
            while ($retryCount < $maxRetries) {
                try {
                    $res = $this->post_url($url, $post_data, $token);
                    
                    if ($res['code'] == 1) {
                        $successCount++;
                        if ($i % 10 == 0) {
                            $output->writeln("已完成: {$i}/{$total} (成功: {$successCount}, 无数据: {$noDataCount}, 失败: {$failCount})");
                        }
                        break;
                    } elseif ($res['code'] == 2) {
                        $noDataCount++;
                        if ($i % 10 == 0) {
                            $output->writeln("已完成: {$i}/{$total} (成功: {$successCount}, 无数据: {$noDataCount}, 失败: {$failCount})");
                        }
                        break;
                    } else {
                        $retryCount++;
                        if ($retryCount < $maxRetries) {
                            $output->writeln("第 {$i} 条失败，尝试重新获取token ({$retryCount}/{$maxRetries}): {$res['msg']}");
                            $token = $this->post_login('https://www.login.com','','');
                            if (!$token) {
                                $output->writeln("第 {$i} 条失败: token获取失败");
                                $failCount++;
                                break;
                            }
                            $this->dynamic_sleep(2, 3);
                        } else {
                            $failCount++;
                            $output->writeln("第 {$i} 条失败，已重试{$maxRetries}次: {$res['msg']}");
                        }        
                    }
                } catch (\Exception $e) {
                    $retryCount++;
                    if ($retryCount < $maxRetries) {
                        $output->writeln("第 {$i} 条异常，尝试重试 ({$retryCount}/{$maxRetries}): " . $e->getMessage());
                        $token = $this->post_login('https://www.login.com','','');
                        if (!$token) {
                            $failCount++;
                            $output->writeln("第 {$i} 条异常: token获取失败");
                            break;
                        }
                        $this->dynamic_sleep(2, 5);
                    } else {
                        $failCount++;
                        $output->writeln("第 {$i} 条异常，已重试{$maxRetries}次: " . $e->getMessage());
                    }
                }
            }
            
            $this->dynamic_sleep();
        }
        
        file_put_contents($progress_file, json_encode([
            'current' => $total,
            'total' => $total,
            'success' => $successCount,
            'no_data' => $noDataCount,
            'fail' => $failCount,
            'start_time' => $startTime,
            'end_time' => time(),
            'status' => 'completed'
        ]));
        
        $cost = time() - $startTime;
        $output->writeln("同步完成! 总耗时: {$cost}秒, 成功: {$successCount}, 无数据: {$noDataCount}, 失败: {$failCount}");
    }

    public function unlock_levels(Input $input, Output $output)
    {
        //php think sync:questions --unlock --start 1 --end 58 --chapter 2 --course 1
        $chapter_id = $input->getOption('chapter') ?: 2;
        $course_id = $input->getOption('course') ?: 1;
        $start_level = $input->getOption('start') ?: 1;
        $end_level = $input->getOption('end') ?: 50;
        $output->writeln("========================================");
        $output->writeln("        关卡解锁工具 v1.0");
        $output->writeln("========================================");
        $output->writeln("章节ID: {$chapter_id}");
        $output->writeln("课程ID: {$course_id}");
        $output->writeln("关卡范围: {$start_level} - {$end_level}");
        $output->writeln("----------------------------------------");
        
        $total_levels = $end_level - $start_level + 1;
        $successCount = 0;
        $failCount = 0;
        $alreadyUnlocked = 0;
        $startTime  = time();
        for ($level = $start_level; $level <= $end_level; $level++) {
            $output->writeln("正在解锁第 {$level}/{$end_level} 关卡...");
            
            $token = $this->post_login('https://www.login.com', '', '');
            if (!$token) {
                $output->writeln("  ✗ 第 {$level} 关: 登录失败，无法获取token");
                $failCount++;
                $this->dynamic_sleep(1, 2);
                continue;
            }
            
            $score_array = [80,85,90,95,100];
            $score = $score_array[array_rand($score_array)];
            
            if($score == 100){
                $star = 3;
            }elseif($score >= 90){
                $star = 2;
            }else{
                $star = 1;
            }
            
            $use_seconds = rand(100, 200);
            
            $next_level = [
                'chapter_id'    => $chapter_id,
                'course_id'     => $course_id,
                'level_id'      => $level,
                'score'         => $score,
                'star'          => $star,
                'use_seconds'   => $use_seconds,
            ];
            
            $maxRetries = 3;
            $retryCount = 0;
            $unlockSuccess = false;
            $lastError = '';
            
            while ($retryCount < $maxRetries) {
                $unlockResult = $this->post_next_level('https://www.baidu.com', $next_level, $token);
                
                if ($unlockResult === false) {
                    $retryCount++;
                    $errorMsg = 'API请求失败';
                    $lastError = $errorMsg;
                    
                    if ($retryCount < $maxRetries) {
                        $output->writeln("  ⚠ 第 {$level} 关: {$errorMsg} (重试 {$retryCount}/{$maxRetries})");
                        $newToken = $this->post_login('https://www.login.com', '', '');
                        if ($newToken) {
                            $token = $newToken;
                            $output->writeln("    → Token已刷新");
                        } else {
                            $output->writeln("    → Token刷新失败");
                        }
                        $this->dynamic_sleep(2, 4);
                    } else {
                        $output->writeln("  ✗ 第 {$level} 关: 解锁失败 - {$errorMsg} (已重试{$maxRetries}次)");
                        $failCount++;
                    }
                    continue;
                }
                
                if ($unlockResult['status'] === 'success') {
                    $output->writeln("  ✓ 第 {$level} 关: 解锁成功 (得分: {$score}, 星级: {$star}, 用时: {$use_seconds}秒)");
                    $successCount++;
                    $unlockSuccess = true;
                    break;
                } elseif ($unlockResult['status'] === 'already_completed') {
                    $output->writeln("  ○ 第 {$level} 关: 已提前通关");
                    $alreadyUnlocked++;
                    $unlockSuccess = true;
                    break;
                } else {
                    $retryCount++;
                    $errorMsg = $unlockResult['message'] ?? '未知错误';
                    $lastError = $errorMsg;
                    
                    if ($retryCount < $maxRetries) {
                        if (strpos($errorMsg, '闯关分数不达标') !== false) {
                            $oldScore = $score;
                            $score = min(100, $score + 10);
                            $star = $score == 100 ? 3 : ($score >= 90 ? 2 : 1);
                            $use_seconds = max(60, $use_seconds - 20);
                            $next_level['score'] = $score;
                            $next_level['star'] = $star;
                            $next_level['use_seconds'] = $use_seconds;
                            $output->writeln("  ⚠ 第 {$level} 关: {$errorMsg} (重试 {$retryCount}/{$maxRetries})");
                            $output->writeln("    → 调整参数: 分数 {$oldScore}→{$score}, 星级 {$star}, 用时 {$use_seconds}秒");
                            $this->dynamic_sleep(2, 4);
                        } else {
                            $output->writeln("  ⚠ 第 {$level} 关: {$errorMsg} (重试 {$retryCount}/{$maxRetries})");
                            $newToken = $this->post_login('https://www.login.com', '', '');
                            if ($newToken) {
                                $token = $newToken;
                                $output->writeln("    → Token已刷新");
                            } else {
                                $output->writeln("    → Token刷新失败");
                            }
                            $this->dynamic_sleep(2, 4);
                        }
                    } else {
                        $output->writeln("  ✗ 第 {$level} 关: 解锁失败 - {$errorMsg} (已重试{$maxRetries}次)");
                        $failCount++;
                    }
                }
            }
            
            $this->dynamic_sleep(45, 60);
        }
        $cost = time() - $startTime;
        $output->writeln("----------------------------------------");
        $output->writeln("解锁完成! 总耗时: {$cost}秒");
        $output->writeln("成功解锁: {$successCount}");
        $output->writeln("已提前通关: {$alreadyUnlocked}");
        $output->writeln("解锁失败: {$failCount}");
        $output->writeln("========================================");
    }

    //模拟登录
    public function post_login($url, $name,$pwd)
    { 
        $headers = ['Content-Type:application/json','X-FORWARDED-FOR:127.0.1.1','CLIENT-IP:127.0.1.1'];
        $post_data = json_encode([
            'password'  =>$pwd,
            'phone'     =>$name,
        ]);
        $useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

        $ch = curl_init();
        // 设置curl超时时间
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_REFERER, 'https://www.google.com/');
        curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // 禁用SSL证书验证（仅在开发环境使用）
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
            curl_close($ch);
            return false;
        }
        $response = json_decode($response, true);
        if (!isset($response['data']['token']) || empty($response['data']['token'])) {
            return false;
        }
        return $response['data']['token'];
    }

     //模拟登录
    public function post_next_level($url, $post_data, $token)
    { 
        $headers   = ['Content-Type:application/json','X-FORWARDED-FOR:127.0.1.1','CLIENT-IP:127.0.1.1','Authorization:Bearer ' . $token];
        $post_data = json_encode($post_data);
        $ch        = curl_init();
        $useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

        $ch = curl_init();
        // 设置curl超时时间
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_REFERER, 'https://www.google.com/');
        // 移除代理设置，直接连接
        curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // 禁用SSL证书验证（仅在开发环境使用）
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
            curl_close($ch);
            return false;
        }
        curl_close($ch);
        $response = json_decode($response, true);
        
        if ($response['code'] == 0 && $response['message'] == 'ok') {
            return ['status' => 'success'];
        } elseif ($response['code'] == 0 && isset($response['message']) && strpos($response['message'], '已通关') !== false) {
            return ['status' => 'already_completed'];
        } else {
            $errorMsg = $response['message'] ?? '未知错误';
            return ['status' => 'failed', 'message' => $errorMsg];
       }
    }
    
    private function post_url($url, $post_data, $token)
    {
        $headers = ['Content-Type:application/json','X-FORWARDED-FOR:127.0.1.1','CLIENT-IP:127.0.1.1', 'Authorization:Bearer ' . $token];
        $useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
        $json_data = json_encode($post_data);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_REFERER, 'https://www.google.com/');
        curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            curl_close($ch);
            return ['code' => 0, 'msg' => 'CURL错误: ' . curl_error($ch)];
        }
        curl_close($ch);
        
        $response = json_decode($response, true);
        if (!isset($response['message']) || $response['message'] != '请求成功') {
            return ['code' => 0, 'msg' => $response['message']];
        }
        
        if (!isset($response['data']['questions']) || empty($response['data']['questions'])) {
            return ['code' => 2, 'msg' => '无题目数据'];
        }
        
        Db::startTrans();
        try {
            $time = time();
            $response_data      = $response['data'];
            $questions          = $response_data['questions'];
            
            $topic_level_data = [
                'level_tip'     => $post_data['chapter_id'],
                'level_num'     => $post_data['course_id'],
                'topic_num'     => count($questions),
                'create_time'   => $time,
                'soft'          => $response_data['level_id'],
                'level_nid'     => $response_data['level_id'],
            ];
            
            $topic_level_id = Db::name('topic_level')->insertGetId($topic_level_data);
            if (!$topic_level_id) {
                Db::rollback();
                return ['code' => 0, 'msg' => '题目等级添加失败'];
            }
            
            $topic_questions = [];
            foreach ($questions as $k => $v) {
                $number = $v['number'];
                $subset_questions = isset($v['questions']) && !empty($v['questions']) ? $v['questions'] : [];
                
                if (!empty($subset_questions)) {
                    foreach ($subset_questions as $qk => $qv) {
                        $question_image = $qv['image'];
                        $question_voice = $qv['voice'];
                        
                        $path_i = './uploads/question/image/' . date('YmdHi', $time).$topic_level_id;
                        if (!file_exists($path_i)) {
                            mkdir($path_i, 0777, true);
                        }
                        $path_image = $path_i . '/img-' . generate_rand_str(6) . $time . '_' . uniqid() . '.jpg';
                        $image_url = $this->download_material($question_image, $path_image);
                        
                        if (!$image_url) {
                            Db::rollback();
                            return ['code' => 0, 'msg' => '图片下载失败'];
                        }
                        
                        $this->dynamic_sleep(2, 3);
                        
                        $path_v = './uploads/question/voice/'. date('YmdHi', $time).$topic_level_id;
                        if (!file_exists($path_v)) {
                            mkdir($path_v, 0777, true);
                        }
                        $path_voice = $path_v . '/voice-' . generate_rand_str(6) . $time . '_' . uniqid() . '.mp3';
                        $voice_url = $this->download_material($question_voice, $path_voice);
                        
                        if (!$voice_url) {
                            if (file_exists($path_image)) {
                                unlink($path_image);
                            }
                            Db::rollback();
                            return ['code' => 0, 'msg' => '音频下载失败'];
                        }
                        
                        $subset_questions[$qk]['image'] = $image_url;
                        $subset_questions[$qk]['voice'] = $voice_url;
                        $subset_questions[$qk]['topic_title'] = $qv['english'];
                    }
                }
                $topic_questions[] = [
                    'tl_id'         => $topic_level_id,
                    'tl_level'      => 1,
                    'tl_difficulty' => 1,
                    'soft'          => $number, 
                    'questions'     => json_encode($subset_questions),
                    'create_time'   => $time,
                ];
            }
            if (!empty($topic_questions)) {
                Db::name('topic_questions')->insertAll($topic_questions);
                $topic_questions = [];
                $this->dynamic_sleep(1, 2);
            }
            
            Db::commit();
            return ['code' => 1, 'msg' => '成功'];
            
        } catch (\Exception $e) {
            Db::rollback();
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    
    private function download_material($url, $path)
    {
        try {
            $remote_file = fopen($url, 'r');
            if (!$remote_file) {
                return false;
            }
            
            $fp = fopen($path, 'w');
            if (!$fp) {
                fclose($remote_file);
                return false;
            }
            
            while (!feof($remote_file)) {
                $chunk = fread($remote_file, 4096);
                if ($chunk === false) {
                    fclose($remote_file);
                    fclose($fp);
                    @unlink($path);
                    return false;
                }
                fwrite($fp, $chunk);
            }
            
            fclose($remote_file);
            fclose($fp);
            
            if (filesize($path) === 0) {
                @unlink($path);
                return false;
            }
            
            return 'http://www.abc.com' . ltrim($path, '.');
            
        } catch (\Exception $e) {
            if (isset($remote_file) && is_resource($remote_file)) {
                fclose($remote_file);
            }
            if (isset($fp) && is_resource($fp)) {
                fclose($fp);
            }
            if (file_exists($path)) {
                @unlink($path);
            }
            return false;
        }
    }
    
    private function dynamic_sleep($base_min = 2, $base_max = 8)
    {
        $current_hour = date('H');
        $hour_factor = 1;
        if ($current_hour >= 0 && $current_hour < 6) {
            $hour_factor = 1.5;
        } elseif ($current_hour >= 18) {
            $hour_factor = 1.2;
        }
        
        $min_sleep = $base_min * $hour_factor;
        $max_sleep = $base_max * $hour_factor;
        $sleep_time = rand($min_sleep * 1000000, $max_sleep * 1000000) / 1000000;
        usleep($sleep_time * 1000000);
    }
}


