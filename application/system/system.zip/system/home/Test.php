<?php

namespace app\system\home;

use app\index\controller\Home;
use think\facade\Env;
use think\Db;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\console\input\Option;

class Test extends Home
{

   //模型生图 - 对接阿里千问Image-Edit-Plus模型
   public function AutoAiImaage(){
      $topic_questions = Db::name('topic_questions')->where('tl_level',1)->where('tl_id',901)->where('soft','in',[6,7])->order('tl_id asc,soft asc')->select();
      if(!empty($topic_questions)){
            foreach ($topic_questions as $key => &$value) {
                $find_question = json_decode($value['questions'],true);
                $is_new_status = 0;
                if(!empty($find_question)){
                    foreach ($find_question as $key_2 => &$value_2) {
                        $image = str_replace('http://www.xyz.com/','/',$value_2['image']);
                        $path_image = '..'.$image;
                        if(file_exists($path_image)) {
                            $path_data   = explode('/img-',$path_image);
                            $path        = $path_data[0];
                            $image_name  = 'ai-img-'.$path_data[1];
                            if(file_exists($path.'/'.$image_name)) {
                                continue;
                            }
                            $base64_data = $this->ImageUrlToBase64($path_image);
                            if($base64_data){
                                $english = $value_2['english'];
                                $prompt  = '参考图的主题含义是："'.$english.'",请按照英文含义保持生成的图片展示内容贴合含义,对背景、人物风格、着装色彩、整体图片布局进行改变(让其看起来和参考图的相似度不高于40%，并生成的图片还能准确的表达出英文所表达的含义),图片风格修改为亚洲现代写实风格;';
                                $result = $this->QianWenAiImage($prompt, $base64_data,$path,$image_name);// 调用千问AI生图API
                                if(!$result){
                                    //异常处理
                                }
                            }
                        }
                    }
                }
            }
       }
       echo 'success';die;
    }

    /**
     * 将图片转换为base64编码
     * @param string $path 图片路径或URL
     * @return string|false 返回base64编码的图片数据或false
     */
    public function ImageUrlToBase64($path){ 
        try {
            // 检查是否为远程URL
            if (filter_var($path, FILTER_VALIDATE_URL)) {
                // 对于远程URL，直接使用file_get_contents获取
                $image_data = file_get_contents($path);
                if ($image_data === false) {
                    throw new Exception('远程图片获取失败');
                }
            } else {
                // 对于本地路径，先检查文件是否存在
                $image_data = file_get_contents($path);
                if ($image_data === false) {
                    throw new Exception('本地图片读取失败');
                }
            }
            // 获取图片MIME类型
            $finfo      = finfo_open(FILEINFO_MIME_TYPE);
            $mime_type  = finfo_buffer($finfo, $image_data);
            finfo_close($finfo);
            
            // 验证是否为有效的图片类型
            if (strpos($mime_type, 'image/') !== 0) {
                throw new Exception('文件不是有效的图片类型');
            }
            // 转换为base64编码
            $base64_data = base64_encode($image_data);
            
            // 返回完整的base64字符串（包含data URI scheme）
            return 'data:' . $mime_type . ';base64,' . $base64_data;
            
        } catch (Exception $e) {
            // 错误处理：可以根据需要记录日志或返回错误信息
            // 这里简单返回false表示失败
            return false;
        }
    }

    public function QianWenAiImage($prompt, $base_image,$path,$image_name){ 
       // 参数验证
       if (empty($prompt) || empty($base_image)) {
           return false;
       }
       try {
           // 2. 调用阿里千问Image-Edit-Plus API
           $access_key_id   = 'sk-96f5eb7a547e4fd1b5387822c6873ba6'; // 请替换为实际的阿里云AccessKey ID
           $api_url         = 'https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation';
           $model           = 'qwen-image-edit-plus';
           // 否则直接使用（假设已经是base64编码）
           $base_image_base64 = $base_image;

            // 验证base64是否有效
            // if (base64_decode($base_image_base64) === false) {
            //     throw new Exception('无效的base64图片数据');
            // }
           // 准备请求参数
           $request_data = [
               'model' => $model,
               'input' => [
                    'messages' => [
                        [
                            'role' => 'user',
                            'content' => [
                                ['image' => $base_image_base64],
                                ['text' => $prompt],
                            ]
                        ]
                    ],
               ],
               'parameters' => [
                   'n' => 1,
                   'negative_prompt' => '',
                   'prompt_extend' => true,
                   'watermark' => false, // 水印
               ]
           ];
           $save_path = $path;
           if(!file_exists($save_path)) {
                mkdir($save_path, 0777, true);
           }
           // 3. 生成阿里云API签名
           $timestamp   = time();
           $nonce       = uniqid();
           $payload     = json_encode($request_data);
           $headers = [
               'Content-Type: application/json; charset=utf-8',
               'Authorization: Bearer ' . $access_key_id
           ];
           // 4. 发送HTTP请求
           $ch = curl_init();
           curl_setopt($ch, CURLOPT_URL, $api_url);
           curl_setopt($ch, CURLOPT_POST, 1);
           curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
           curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
           curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
           
           $response = curl_exec($ch);
           $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
           
           if (curl_errno($ch)) {
               throw new Exception('API请求失败: ' . curl_error($ch));
           }
           
           curl_close($ch);
           // 5. 处理API响应
           $result = json_decode($response, true);
           if ($http_code !== 200 || !isset($result['output']['choices'][0]['message']['content'][0]['image'])) {
               throw new Exception('API调用失败: ' . ($result['message'] ?? '未知错误'));
           }
           
           // 6. 下载生成的图片
           $generated_image_url     = $result['output']['choices'][0]['message']['content'][0]['image'];
           $generated_image_content = file_get_contents($generated_image_url);
           if (!$generated_image_content) {
               throw new Exception('下载生成的图片失败');
           }
           
           // 7. 保存新图片
           $full_path = $save_path . '/'.$image_name;
           // 保存图片
           if (file_put_contents($full_path, $generated_image_content)) {
               return true;  // 返回结果
           } else {
               throw new Exception('保存图片失败');
           }
       } catch (Exception $e) {
           return false;
       }
    }

    // public function test(){
    //     $level_list = Db::name('topic_level')->where('level_tip',2)->where('level_num',1)->select();
    //     if(!empty($level_list)){
    //        $level_res =  Db::name('topic_level')->where('level_tip',2)->where('level_num',1)->update(['level_tip'=>1,'level_num'=>2,'update_time'=>time()]);
    //        echo $level_res;
    //        echo '<br>';
    //     }
    //     $questions_list = Db::name('topic_questions')->where('tl_difficulty',2)->where('tl_level',1)->select();
    //     if(!empty($questions_list)){
    //         $questions_res =  Db::name('topic_questions')->where('tl_difficulty',2)->where('tl_level',1)->update(['tl_difficulty'=>1,'tl_level'=>2,'update_time'=>time()]);
    //         echo $questions_res;
    //     }
    //     die;
    // }

}
